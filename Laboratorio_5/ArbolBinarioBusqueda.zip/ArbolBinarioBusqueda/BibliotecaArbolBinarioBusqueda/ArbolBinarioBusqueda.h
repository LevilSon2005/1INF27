//Fecha:  jueves 30 Octubre 2025 
//Autor: Ana Roncal 

#ifndef ARBOLBINARIOBUSQUEDA_ARBOLBINARIOBUSQUEDA_H
#define ARBOLBINARIOBUSQUEDA_ARBOLBINARIOBUSQUEDA_H
#include "NodoArbolBinarioBusqueda.h"
struct ArbolBinarioBusqueda {
    struct NodoArbolBinarioBusqueda * raiz;
};
#endif //ARBOLBINARIOBUSQUEDA_ARBOLBINARIOBUSQUEDA_H